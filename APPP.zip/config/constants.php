<?php
return [
    'PROJ_INFO' => 9,
    'LU_BUDGET_YEAR' => 10,
    'LU_PROJ_STATUS' => 11,
    'LU_DEPARTMENT' => 12,
    'LU_BUDGET_SOURCE' => 13,
    'PROJ_PAYMENT' => 14,
    'PROJ_CONTRACTOR' => 15,
    'PROJ_STAKEHOLDER' => 16,
    'LU_CATEGORY' => 17,
    'LU_DOCUMENT_TYPE' => 18,
    'UA_ROLE' => 19,
    'LU_SECTOR_INFO' => 20,
    'UA_USER' => 21,
    'UA_USER_ROLE' => 22,
    'UA_ADDRESS' => 24
    ];
    ?>